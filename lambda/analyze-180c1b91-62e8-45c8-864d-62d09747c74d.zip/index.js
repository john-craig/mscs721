exports.handler = async (event) => {
    var response = {
        statusCode: 500,
        body: "Critical error",
    };
    
    //Check that the event is an object
    if(typeof event == "object"){
        //Check that the "body" key is specified in the event object
        if(event["body"] !== undefined){
            //Check that the value of body is a string
            if(typeof event["body"]  == "string"){
                response.statusCode = 200;
                response.body = analyzeConcordance(event["body"]);
                
            } else {
                response.statusCode = 402;
                response.body = "Expected 'body' value to be string";
            }
        } else {
            response.statusCode = 401;
            response.body = "Expected JSON object with 'body' key specified";
        }
    } else {
        response.statusCode = 400;
        response.body = "Did not recieve a JSON object as an argument"
    }
    
    return response;
};


function analyzeConcordance(body){
    var concordance = []
    var partialConcordance = {}
    var tokens = body.split(' ')
    
    tokens = standardize(tokens)
    tokens.sort()
    
    tokens.forEach(token => {
        if(partialConcordance[token] == undefined) {
          partialConcordance[token] = 1
        } else {
          partialConcordance[token] = partialConcordance[token] + 1
        }
    })
    
    concordance = Object.keys(partialConcordance).map(key => {
        return {
          "token": key,
          "count": partialConcordance[key]
        }
    })
    
    return {
        "input": body,
        "concordance": concordance
    }
}

function standardize(stringArray){
  const standardizedArray = stringArray.map(element => {
    var standardized = element

    standardized = standardized.toLowerCase()
    standardized = standardized.replace(/[^0-9a-z]/gi, '')

    return standardized
  })

  return standardizedArray
}